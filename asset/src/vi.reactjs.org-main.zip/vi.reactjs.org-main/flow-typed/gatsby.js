/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 */

declare module 'gatsby' {
  declare module.exports: any;
}

/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 */

declare module 'slugify' {
  declare module.exports: any;
}

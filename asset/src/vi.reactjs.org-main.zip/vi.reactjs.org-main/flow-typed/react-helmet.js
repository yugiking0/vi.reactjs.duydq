/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 */

declare module 'react-helmet' {
  declare module.exports: any;
}

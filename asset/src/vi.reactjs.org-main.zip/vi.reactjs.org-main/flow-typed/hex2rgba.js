/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 */

declare module 'hex2rgba' {
  declare module.exports: (hex: string, alpha?: number) => string;
}

---
title: Một ứng dụng
order: 2
domid: todos-example
---

 Chúng ta có thể sử dụng kết hợp `props` và` state` cho một ứng dụng Todo nhỏ. Ví dụ này sử dụng `state` để theo dõi danh sách các mục hiện tại cũng như văn bản mà người dùng đã nhập. Mặc dù các trình xử lý sự kiện được hiển thị cùng dòng, chúng sẽ được thu thập và triển khai bằng cách sử dụng các sự kiện.
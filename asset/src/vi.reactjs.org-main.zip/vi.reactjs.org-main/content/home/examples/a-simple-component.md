---
title: Ví dụ Component
order: 0
domid: hello-example
---

Các React component thực hiện một phương thức `render ()` lấy dữ liệu đầu vào và trả về những gì sẽ hiển thị. Ví dụ này sử dụng cú pháp giống như XML có tên là JSX. Dữ liệu đầu vào được truyền vào component có thể được truy cập bằng `render ()` qua `this.props`.

**JSX là tùy chọn và không bắt buộc khi sử dụng React.** Hãy thử [Babel REPL](babel://es5-syntax-example) để xem mã JavaScript ban đầu được tạo bởi bước biên dịch JSX.
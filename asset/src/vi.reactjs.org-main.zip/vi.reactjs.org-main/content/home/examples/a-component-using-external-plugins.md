---
title: Component sử dụng các plugin bên ngoài
order: 3
domid: markdown-example
---

React cho phép bạn giao tiếp với các thư viện và frameworks. Ví dụ này sử dụng **remarkable**, một thư viện Markdown bên ngoài, để chuyển đổi giá trị của `<textarea>` trong thời gian thực.
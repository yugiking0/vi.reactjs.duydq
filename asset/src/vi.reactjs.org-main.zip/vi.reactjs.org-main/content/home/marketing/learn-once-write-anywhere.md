---
title: Learn Once, Write Anywhere
order: 2
---

Chúng tôi không đưa ra các giả định về phần kĩ năng công nghệ của bạn, vì vậy bạn có thể phát triển các tính năng mới trong React mà không cần viết lại mã hiện có.

React cũng có thể render trên máy chủ bằng Node và xây dựng ứng dụng di động bằng cách sử dụng [React Native](https://reactnative.dev/).

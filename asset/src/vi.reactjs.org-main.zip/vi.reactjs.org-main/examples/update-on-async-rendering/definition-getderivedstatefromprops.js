class Example extends React.Component {
  static getDerivedStateFromProps(props, state) {
    // ...
  }
}

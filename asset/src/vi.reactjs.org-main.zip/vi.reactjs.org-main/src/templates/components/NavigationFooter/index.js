/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * @emails react-core
 */

import NavigationFooter from './NavigationFooter';

export default NavigationFooter;

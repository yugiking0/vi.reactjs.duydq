/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * @emails react-core
 */

import Sidebar from './Sidebar';

export default Sidebar;

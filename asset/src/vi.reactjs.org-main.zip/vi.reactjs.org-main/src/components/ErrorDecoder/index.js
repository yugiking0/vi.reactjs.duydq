/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * @emails react-core
 */

import ErrorDecoder from './ErrorDecoder';

export default ErrorDecoder;

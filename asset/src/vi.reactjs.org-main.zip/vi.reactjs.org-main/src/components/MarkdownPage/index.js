/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * @emails react-core
 */

import MarkdownPage from './MarkdownPage';

export default MarkdownPage;
